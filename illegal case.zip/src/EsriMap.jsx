import React, { useEffect } from 'react';

const PORTAL_URL = 'https://gh.space.gov.rw/portal/';
const WEBMAP_ID = '71f7636be6f14ed287abd35e857569ca';
// TODO: replace with your actual registered OAuth app client ID in Portal
const OAUTH_CLIENT_ID = 'YOUR_PORTAL_CLIENT_ID_HERE';

function EsriMap() {
  useEffect(() => {
    function waitForRequire(timeoutMs = 8000) {
      return new Promise((resolve) => {
        if (typeof window.require === 'function') return resolve();
        const deadline = Date.now() + timeoutMs;
        const t = setInterval(() => {
          if (typeof window.require === 'function') {
            clearInterval(t);
            resolve();
            return;
          }
          if (Date.now() > deadline) {
            clearInterval(t);
            resolve();
          }
        }, 80);
      });
    }

    let view;

    waitForRequire().then(() => {
      if (!window.require) return;

      window.require(
        ['esri/WebMap', 'esri/views/MapView', 'esri/config', 'esri/identity/IdentityManager'],
        (WebMap, MapView, esriConfig, IdentityManager) => {
          esriConfig.portalUrl = PORTAL_URL;

          const sharingUrl = `${PORTAL_URL}sharing`;

          // Ensure the user is authenticated with the Portal before loading secured WebMap/layers
          IdentityManager.checkSignInStatus(sharingUrl)
            .catch(() => {
              // Not signed in yet – trigger OAuth sign-in (popup flow)
              return IdentityManager.getCredential(sharingUrl, {
                oAuthAppId: OAUTH_CLIENT_ID,
                popup: true,
              });
            })
            .then(() => {
              const webmap = new WebMap({
                portalItem: {
                  id: WEBMAP_ID,
                  portal: { url: PORTAL_URL },
                },
              });

              view = new MapView({
                container: 'esri-map-container',
                map: webmap,
                ui: { components: ['zoom'] },
                popup: { autoOpenEnabled: false },
              });

              // Expose the view immediately for dashboard to attach widgets
              window.__ICM_VIEW__ = view;

              // Once the WebMap and view are ready, zoom and expose the case layer
              webmap.when(() => {
                try {
                  const caseLayer =
                    webmap.allLayers &&
                    webmap.allLayers.find(
                      (l) =>
                        l.type === 'feature' &&
                        l.url &&
                        l.url.toLowerCase().includes('case_inspection'),
                    );
                  if (caseLayer) {
                    window.__ICM_FL__ = caseLayer;
                  } else {
                    // Helpful diagnostic if the expected layer isn't present
                    // eslint-disable-next-line no-console
                    console.error(
                      '[EsriMap] case_inspection layer not found in WebMap. Check WebMap layers or matching logic.',
                    );
                  }
                } catch (e) {
                  // eslint-disable-next-line no-console
                  console.error('[EsriMap] Error resolving case layer from WebMap:', e);
                }
              });

              view.when().then(() => {
                view.goTo(
                  { center: [30.0619, -1.9441], zoom: 11 },
                  { duration: 600 },
                );
              });
            });
        },
      );
    });

    return () => {
      if (view) {
        view.container = null;
        view.destroy();
      }
      if (window.__ICM_VIEW__) window.__ICM_VIEW__ = null;
    };
  }, []);

  return (
    <div
      id="esri-map-container"
      style={{ width: '100%', height: '100%' }}
    />
  );
}

export default EsriMap;

